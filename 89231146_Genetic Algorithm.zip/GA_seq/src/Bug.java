import java.util.Random;

public class Bug {
    Random random;
    char[] movements=new char[500];
    int hunger=10;
    public Bug(){
        random = new Random();
        makeMove();
    }
    public Bug(Bug b){
        this.movements= b.movements;
        this.hunger=b.hunger;
    }
    public void makeMove(){
        for(int i=0;i<500;i++){
            int move = random.nextInt(4);
            switch (move){
                case 0:
                    movements[i] = 'R';
                    break;
                case 1:
                    movements[i] = 'L';
                    break;
                case 2:
                    movements[i] = 'U';
                    break;
                case 3:
                    movements[i] = 'D';
                    break;
            }
        }
    }
}
