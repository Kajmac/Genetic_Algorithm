import javax.swing.*;

public class GA_Frame extends JFrame {
    GA_Frame(){
        this.add(new GA_Panel());
        this.setTitle("Genetic Algorithm");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}
