public class GA_Main {
    public static void main(String[] args){
        new GA_Frame();

    }
}
