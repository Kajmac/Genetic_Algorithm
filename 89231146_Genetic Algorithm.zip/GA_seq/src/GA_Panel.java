import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;


public class GA_Panel extends JPanel implements ActionListener{
    static final int width=600;
    static final int height=600;
    static final int unit_size=25;
    static final int delay=1;
    int food[][]=new int[width/unit_size][height/unit_size];
    Random random;
    Timer timer;
    boolean running=false;
    int incr=0;
    int incr2=0;
    Bug mother=null;
    Bug father=null;

    Bug[] buggy=new Bug[4];
    boolean initPop=true;
    int bugPosX=width/unit_size/2;
    int bugPosY=height/unit_size/2;

    GA_Panel(){
        random = new Random();
        this.setPreferredSize(new Dimension(width,height));
        this.setBackground(Color.black);
        this.setFocusable(true);
        startAlgo();
    }
    public void startAlgo(){
        timer=new Timer(delay,this);
        timer.start();
        startingFood();
        bugs();
        running=true;
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    public void draw(Graphics g){
        for(int i=0;i<height/unit_size;i++){
            g.drawLine(i*unit_size,0,i*unit_size,height);
        }
        for(int i=0;i<width/unit_size;i++){
            g.drawLine(0,i*unit_size,width,i*unit_size);
        }

        for(int i=0;i<width/unit_size;i++){
            for(int j=0;j<height/unit_size;j++) {
                if (food[i][j] == 1) {
                    g.setColor(Color.red);
                    g.fillOval(i*unit_size, j*unit_size, unit_size, unit_size);
                }
                if(food[i][j]==2){
                    g.setColor(Color.yellow);
                    g.fillOval(i*unit_size, j*unit_size, unit_size, unit_size);
                }
            }
        }
        g.setColor(Color.white);
        g.fillRect(bugPosX*unit_size,bugPosY*unit_size,unit_size,unit_size);
    }
    public void startingFood(){
        for(int i=0;i<10;i++) {
            boolean helper = false;
            while(!helper) {
                int fill1 = random.nextInt(height / unit_size);
                int fill2 = random.nextInt(width / unit_size);
                if(food[fill1][fill2]==0){
                    food[fill1][fill2]=1;
                    helper=true;
                }
            }
        }
    }
    public void move(char c){
            switch (c){
                case 'U':
                    bugPosY++;
                    break;
                case 'D':
                    bugPosY--;
                    break;
                case 'R':
                    bugPosX++;
                    break;
                case 'L':
                    bugPosX--;
                    break;
            }
            checkWall();
    }
    public void checkFood(int i, int j, Bug b){
        if(food[i][j]==1){
            food[i][j]=2;
            b.hunger--;
        }
    }
    public void checkWall(){
        if(bugPosX>23){
            bugPosX=23;
        }
        else if(bugPosX<0){
            bugPosX=0;
        }
        else if(bugPosY>23){
            bugPosY=23;
        }
        else if(bugPosY<0){
            bugPosY=0;
        }
    }
    public void replenishFood(){
        for(int i=0;i<width/unit_size;i++){
            for(int j=0;j<height/unit_size;j++) {
                if(food[i][j]==2) food[i][j]=1;
            }}
    }
    public void bugs(){
        if(initPop){
            for(int i=0;i<4;i++){
                buggy[i] = new Bug();
            }
            initPop=false;
        }
        else{
            incr2=0;
            incr=0;
            selection(buggy);
            crossover(buggy);
            mutate(buggy);
            replenishFood();
        }
    }

    public void mutate(Bug[] b){
        for(int j=0;j<b.length;j++){
            for(int i=0;i<b[j].movements.length;i++){
                if(random.nextInt(10)==9){
                    int move = random.nextInt(4);
                    switch (move){
                        case 0:
                            b[j].movements[i] = 'R';
                            break;
                        case 1:
                            b[j].movements[i] = 'L';
                            break;
                        case 2:
                            b[j].movements[i] = 'U';
                            break;
                        case 3:
                            b[j].movements[i] = 'D';
                            break;
                    }
                }
            }
        }
    }

    public void selection(Bug[] b){
        int min=11;
        int min2=12;
        for(int i=0;i<4;i++){

            if(b[i].hunger<min){
                min2=min;
                min=b[i].hunger;
                father=mother;
                mother=b[i];
            }
            else if(b[i].hunger<min2){
                min2=b[i].hunger;
                father=b[i];
            }
        }
    }
    public void crossover(Bug[] b){
        Bug bugson1 = new Bug(father);
        Bug bugson2 = new Bug(father);
        Bug bugdaughter1 = new Bug(mother);
        Bug bugdaughter2 = new Bug(mother);
        for(int i=bugson1.movements.length/2-1;i<bugson1.movements.length;i++){
            for(int j=0;j<bugson1.movements.length/2-1;j++){
                bugson1.movements[i]=mother.movements[j];
                bugson2.movements[i]=mother.movements[i];
                bugdaughter1.movements[i]=father.movements[j];
                bugdaughter2.movements[i]=father.movements[i];
            }
        }


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(running){

            move(buggy[incr2].movements[incr]);
            checkFood(bugPosX,bugPosY,buggy[incr2]);
            incr++;
            if(incr==499){
                if(incr2==3) bugs();
                else{
                    incr2++;
                    incr=0;
                    bugPosX=width/unit_size/2;
                    bugPosY=height/unit_size/2;
                    replenishFood();
                }
            }
            repaint();
        }
    }
}
