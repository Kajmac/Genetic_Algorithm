public class GA_para_main {
    public static void main(String[] args){
        new GA_para_frame();

    }
}
