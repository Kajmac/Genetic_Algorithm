import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.CyclicBarrier;

public class GA_para_panel extends JPanel{
    GA_para_panel(){
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setFocusable(true);
    }

    static final int SCREEN_WIDTH = 600;
    static final int SCREEN_HEIGHT = 600;
    static final int UNIT_SIZE = 10;
    static final int GAME_UNITS = (SCREEN_HEIGHT * SCREEN_WIDTH) / UNIT_SIZE;
    static final int DELAY = 1;
    static int[][] food = new int[SCREEN_WIDTH/UNIT_SIZE][SCREEN_HEIGHT/UNIT_SIZE];
    final int amount_of_food = 20;
    Random random;
    boolean initialPopulation = true;
    final static int populationSize = 24;
    GA_para_bug[] buggy = new GA_para_bug[populationSize];
    static boolean done = false;
    int mutationRate = GA_para_bug.genes/50;
    int numberOfParents = 4;
    GA_para_bug[] parents = new GA_para_bug[numberOfParents];
    int generationNumber = 1;
    int generationsWithoutChange=0;
    int lastGenBest = amount_of_food;
    int mutationUpCounter=999;
    public static CyclicBarrier barrier;

    public void startAlgo(){

        makeFood();
        populate();
        barrier = new CyclicBarrier(populationSize, () -> {

            boolean generationFinished = true;

            for (GA_para_bug bug : buggy) {
                if (bug.mover < GA_para_bug.genes) {
                    generationFinished = false;
                    break;
                }
            }

            if (generationFinished) {
                if(!done){
                crossBreed();
                replenishFood();
                generationNumber++;}
                else{
                    for (GA_para_bug bug : buggy) {
                        bug.stopBug();
                    }
                }
            }
            try {
                Thread.sleep(DELAY);
            } catch (InterruptedException e) {}
            repaint();
        });

        for(int i = 0; i < populationSize; i++){
            buggy[i].start();
        }
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    public void draw(Graphics g){
        if(!done){
            //drawing environment
            for(int i=0; i<SCREEN_HEIGHT/UNIT_SIZE; i++){
                g.drawLine(i * UNIT_SIZE,0,i * UNIT_SIZE,SCREEN_HEIGHT);
                g.drawLine(0,i * UNIT_SIZE,SCREEN_WIDTH,i * UNIT_SIZE);
            }
            //drawing food
            for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++){
                for(int j=0;j<SCREEN_WIDTH/UNIT_SIZE;j++){
                    if (food[i][j] == 1){
                        g.setColor(Color.red);
                        g.fillOval(i*UNIT_SIZE,j*UNIT_SIZE,UNIT_SIZE,UNIT_SIZE);
                    }
                    else if (food[i][j]>1){
                        Color foodColor = new Color(Color.yellow.getRGB()+food[i][j]*10);
                        g.setColor(foodColor);
                        g.fillOval(i*UNIT_SIZE,j*UNIT_SIZE,UNIT_SIZE,UNIT_SIZE);
                    }
                }
            }
            //drawing bugs
            g.setColor(Color.white);
            for(int i=0;i<populationSize;i++){
                g.fillRect(buggy[i].currentX*UNIT_SIZE, buggy[i].currentY*UNIT_SIZE, UNIT_SIZE,UNIT_SIZE);
            }
            //generation display up top
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Generation: " + generationNumber, 10, 20);
        }
        //algorithm is done notification
        else{
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("A bug from batch " + generationNumber + " found the required quantity", (SCREEN_WIDTH-metrics.stringWidth("A bug from generation x found the required quantity"))/2,SCREEN_HEIGHT/2);
            g.drawString("of food to survive and teach it's youngins!", (SCREEN_WIDTH-metrics.stringWidth("of food to survive and teach it's youngins!"))/2,(SCREEN_HEIGHT/2)+30);
        }
    }

    public void makeFood(){
        if(initialPopulation){
            for (int i=0; i<amount_of_food; i++){
                int foodX=random.nextInt(SCREEN_WIDTH/UNIT_SIZE);
                int foodY=random.nextInt(SCREEN_HEIGHT/UNIT_SIZE);
                if (food[foodX][foodY]<=0) {
                    food[foodX][foodY]=1;
                }
                else i--;
            }
        }
    }
    public void replenishFood(){
        for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++){
            for(int j=0;j<SCREEN_WIDTH/UNIT_SIZE;j++){
                if(food[i][j]!=0) food[i][j]=1;
            }
        }
    }

    public void populate(){
        if(initialPopulation){
            initialPopulation = false;
            for (int i = 0; i < populationSize; i++) buggy[i] = new GA_para_bug();

        }
        else crossBreed();
    }

    public void crossBreed(){
        //the following is so our bugs don't get stuck repeating "bad moves"
        selection(buggy);
        int min = findBest(parents);
        if(lastGenBest > min){
            lastGenBest = min;
        }
        else generationsWithoutChange++;
        if(generationsWithoutChange>=2){
            mutationRate/=2;
            generationsWithoutChange=0;
            mutationUpCounter=1;
        }
        if(mutationUpCounter==0){
            mutationUpCounter=999;
            mutationRate*=2;
        }
        mutationUpCounter--;
        //now my children shall be born
        int parent1=0;
        int parent2=0;
        for(int i=0;i<numberOfParents;i++){
            buggy[i].movements = parents[i].movements;
            //elitism
        }
        for(int i=numberOfParents-1;i<populationSize;i++){
            boolean helper = true;
            while(helper){
                parent1 = random.nextInt(4);
                parent2 = random.nextInt(4);
                if(parent1!=parent2) helper = false;
            }
            int geneSplit = random.nextInt(GA_para_bug.genes);
            for(int j=0;j<geneSplit;j++){
                buggy[i].movements[j]=parents[parent1].movements[j];
                mutate(buggy[i], j);
            }
            for(int j = geneSplit;j< GA_para_bug.genes;j++){
                buggy[i].movements[j]=parents[parent2].movements[j];
                mutate(buggy[i], j);
            }
        }
        for(GA_para_bug bug : buggy){
            bug.hunger = GA_para_bug.originalHunger;
            for(int i=0;i<SCREEN_WIDTH/UNIT_SIZE;i++){
                for(int j=0;j<SCREEN_HEIGHT/UNIT_SIZE;j++){
                    bug.pickedFood[i][j]=0;
                }
            }
            bug.currentX = SCREEN_WIDTH/UNIT_SIZE/2;
            bug.currentY = SCREEN_WIDTH/UNIT_SIZE/2;
            bug.mover=0;
        }

    }

    public void mutate(GA_para_bug buug, int i){
        if (random.nextInt(mutationRate) == 1){
            int newMove = random.nextInt(4);
            switch(newMove){
                case 0: buug.movements[i] = 'L'; break;
                case 1: buug.movements[i] = 'R'; break;
                case 2: buug.movements[i] = 'D'; break;
                case 3: buug.movements[i] = 'U'; break;
            }
        }
    }
    public int findBest(GA_para_bug[] bug){
        int min = bug[0].hunger;
        for (int i = 1; i < bug.length; i++) {
            if (bug[i].hunger < min) {
                min = bug[i].hunger;
            }
        }
        return min;
    }
    public void selection(GA_para_bug[] buug) {
        int[] minimals = new int[numberOfParents];
        Arrays.fill(minimals, Integer.MAX_VALUE);
        for (int i = 0; i < buug.length; i++) {
            int x = buug[i].hunger;
            int worst = 0;
            for (int j = 1; j < numberOfParents; j++) {
                if (minimals[j] > minimals[worst]) {
                    worst = j;
                }
            }
            if (x < minimals[worst]) {
                minimals[worst] = x;
                parents[worst] = buug[i];
            }
        }
    }
}
