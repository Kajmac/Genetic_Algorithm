import javax.swing.*;
import java.util.Random;

public class GA_para_bug extends Thread{
    Random rand;
    static final int genes = GA_para_panel.GAME_UNITS/10;
    char[] movements = new char[genes];
    int[][] pickedFood = new int[GA_para_panel.SCREEN_WIDTH/ GA_para_panel.UNIT_SIZE][GA_para_panel.SCREEN_HEIGHT/ GA_para_panel.UNIT_SIZE];
    static int originalHunger = 13;
    int hunger = originalHunger;
    int currentX = GA_para_panel.SCREEN_WIDTH/GA_para_panel.UNIT_SIZE/2;
    int currentY = GA_para_panel.SCREEN_HEIGHT/GA_para_panel.UNIT_SIZE/2;
    int mover=0;
    boolean running = true;

    public GA_para_bug(){
        this.rand = new Random();
        this.makeMove();
    }

    private void makeMove(){
        for(int i=0;i<movements.length;i++){
            int movement = rand.nextInt(4);
            switch (movement){
                case 0:
                    movements[i] = 'R';
                    break;
                case 1:
                    movements[i] = 'L';
                    break;
                case 2:
                    movements[i] = 'U';
                    break;
                case 3:
                    movements[i] = 'D';
                    break;
            }
        }
    }
    public void checkWall(){
        if(currentX > GA_para_panel.SCREEN_WIDTH/GA_para_panel.UNIT_SIZE-1) currentX=GA_para_panel.SCREEN_WIDTH/GA_para_panel.UNIT_SIZE-1;
        if(currentY > GA_para_panel.SCREEN_HEIGHT/GA_para_panel.UNIT_SIZE-1) currentY=GA_para_panel.SCREEN_HEIGHT/GA_para_panel.UNIT_SIZE-1;
        if(currentX < 0) currentX=0;
        if(currentY < 0) currentY=0;
    }
    public void checkFood(){
        if(GA_para_panel.food[currentX][currentY]>0){
            if(pickedFood[currentX][currentY]==0){
            this.hunger--;
            GA_para_panel.food[currentX][currentY]++;
            pickedFood[currentX][currentY] = 1;
            }
        }
        if(this.hunger == 0) GA_para_panel.done=true;
    }
    public void move(char c){
        switch (c){
            case 'L': currentX--; break;
            case 'R': currentX++; break;
            case 'D': currentY--; break;
            case 'U': currentY++; break;
        }
        checkWall();
        checkFood();
    }

    public void stopBug(){running=false;}

    @Override
    public void run() {

        while (running) {
            if (mover < genes) {
                move(movements[mover]);
                mover++;
            }
            try {
                GA_para_panel.barrier.await();
            } catch (Exception e) {}
        }
    }
}
