import javax.swing.*;

public class GA_para_frame extends JFrame {

    GA_para_panel panel;

    GA_para_frame() {

        panel = new GA_para_panel();
        SwingUtilities.invokeLater(() -> {
            panel.startAlgo();
        });
        this.add(panel);

        this.setTitle("GA");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);


    }
}