import mpi.MPI;

import javax.swing.*;

public class GA_dist_frame extends JFrame {

    GA_dist_panel panel;

    GA_dist_frame() {
        panel = new GA_dist_panel();
        this.add(panel);
        int batch = MPI.COMM_WORLD.Rank() + 1;
        this.setTitle("GA batch " + batch);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);

            panel.startAlgo();


    }


}