import mpi.MPI;

import java.io.Serializable;
import java.util.Random;
import java.util.concurrent.BrokenBarrierException;

public class GA_dist_bug implements Serializable {
    Random rand;
    static final int genes = GA_dist_panel.GAME_UNITS/10;
    char[] movements = new char[genes];
    int[][] pickedFood = new int[GA_dist_panel.SCREEN_WIDTH/ GA_dist_panel.UNIT_SIZE][GA_dist_panel.SCREEN_HEIGHT/ GA_dist_panel.UNIT_SIZE];
    static int originalHunger = 20;
    int hunger = originalHunger;
    int currentX = GA_dist_panel.SCREEN_WIDTH/GA_dist_panel.UNIT_SIZE/2;
    int currentY = GA_dist_panel.SCREEN_HEIGHT/GA_dist_panel.UNIT_SIZE/2;
    int mover=0;


    static int[] localDone = new int[1];
    static int[] globalDone = new int[1];

    public GA_dist_bug(){
        this.rand = new Random();
        this.makeMove();
    }

    private void makeMove(){
        for(int i=0;i<movements.length;i++){
            int movement = rand.nextInt(4);
            switch (movement){
                case 0:
                    movements[i] = 'R';
                    break;
                case 1:
                    movements[i] = 'L';
                    break;
                case 2:
                    movements[i] = 'U';
                    break;
                case 3:
                    movements[i] = 'D';
                    break;
            }
        }
    }
    public void checkWall(){
        if(currentX > GA_dist_panel.SCREEN_WIDTH/GA_dist_panel.UNIT_SIZE-1) currentX=GA_dist_panel.SCREEN_WIDTH/GA_dist_panel.UNIT_SIZE-1;
        if(currentY > GA_dist_panel.SCREEN_HEIGHT/GA_dist_panel.UNIT_SIZE-1) currentY=GA_dist_panel.SCREEN_HEIGHT/GA_dist_panel.UNIT_SIZE-1;
        if(currentX < 0) currentX=0;
        if(currentY < 0) currentY=0;
    }
    public void checkFood(){
        if(GA_dist_panel.food[currentX][currentY]>0){
            if(pickedFood[currentX][currentY]==0){
                this.hunger--;
                GA_dist_panel.food[currentX][currentY]++;
                pickedFood[currentX][currentY] = 1;
            }
        }
        if(this.hunger == 0) {
            localDone[0]=1;
            GA_dist_panel.Lrank0[0]=MPI.COMM_WORLD.Rank();
        }
    }
    public void move(char c){
        switch (c){
            case 'L': currentX--; break;
            case 'R': currentX++; break;
            case 'D': currentY--; break;
            case 'U': currentY++; break;
        }
        checkWall();
        checkFood();
    }
}
