import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import mpi.*;

public class GA_dist_main {
    public static void main(String[] args) {

        MPI.Init(args);

        new GA_dist_frame();

        MPI.Finalize();
    }
}
