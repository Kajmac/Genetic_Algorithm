import mpi.MPI;
import javax.swing.*;
import java.awt.*;
import java.util.Random;


public class GA_dist_panel extends JPanel {
    GA_dist_panel(){
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setFocusable(true);
    }

    static final int SCREEN_WIDTH = 400;
    static final int SCREEN_HEIGHT = 400;
    static final int UNIT_SIZE = 10;
    static final int GAME_UNITS = (SCREEN_HEIGHT * SCREEN_WIDTH) / UNIT_SIZE;
    static final int DELAY = 1;
    static int[][] food = new int[SCREEN_WIDTH/UNIT_SIZE][SCREEN_HEIGHT/UNIT_SIZE];
    final int amount_of_food = 20;
    Random random;
    boolean initialPopulation = true;
    final static int populationSize = 24;
    GA_dist_bug[] buggy = new GA_dist_bug[populationSize];
    static boolean done = false;
    int mutationRate = GA_dist_bug.genes/50;
    int numberOfParents = 4;;
    GA_dist_bug[] parents = new GA_dist_bug[numberOfParents];
    int generationNumber = 1;
    int generationsWithoutChange=0;
    int lastGenBest = amount_of_food;
    int mutationUpCounter=999;


    final static int batchSize = 6;
    GA_dist_bug[]  parentBug = new GA_dist_bug[1];
    private final int rank = MPI.COMM_WORLD.Rank();
    public static int[] Lrank0 = {999};
    public static int[] Grank0 = {999};
    GA_dist_bug[] recvBugs = new GA_dist_bug[batchSize];
    int[] foodAsArray = new int[SCREEN_WIDTH / UNIT_SIZE * SCREEN_HEIGHT / UNIT_SIZE];



    public void startAlgo()  {
        if(rank == 0){
            if(initialPopulation){
                makeFood();
                populate();
                initialPopulation=false;
                for(int i=0;i<SCREEN_WIDTH / UNIT_SIZE;i++){
                    for(int j=0;j<SCREEN_HEIGHT / UNIT_SIZE;j++){
                        foodAsArray[i*SCREEN_WIDTH/UNIT_SIZE+j] = food[i][j];
                    }
                }
            }
        }
        MPI.COMM_WORLD.Bcast(foodAsArray,0,foodAsArray.length, MPI.INT, 0 );
        MPI.COMM_WORLD.Scatter(buggy,0,batchSize,MPI.OBJECT,recvBugs,0,recvBugs.length,MPI.OBJECT,0);
        foodIntoMatrix(foodAsArray,food);

        while(!done){
                boolean generationFinished = true;
                for (GA_dist_bug bug : recvBugs) {
                    if (bug.mover < bug.genes) {
                        generationFinished = false;
                        bug.move(bug.movements[bug.mover]);
                        bug.mover++;
                    }
                }
                try {
                    Thread.sleep(DELAY);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                repaint();
                if(generationFinished) makeMPIcall();
        }
        repaint();
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        draw(g);
    }
    public void draw(Graphics g){
        if(!done){
            //drawing grid
            for(int i=0; i<SCREEN_HEIGHT/UNIT_SIZE; i++){
                g.drawLine(i * UNIT_SIZE,0,i * UNIT_SIZE,SCREEN_HEIGHT);
                g.drawLine(0,i * UNIT_SIZE,SCREEN_WIDTH,i * UNIT_SIZE);
            }
            //drawing food
            for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++){
                for(int j=0;j<SCREEN_WIDTH/UNIT_SIZE;j++){
                    if (food[i][j] == 1){
                        g.setColor(Color.red);
                        g.fillOval(i*UNIT_SIZE,j*UNIT_SIZE,UNIT_SIZE,UNIT_SIZE);
                    }
                    else if (food[i][j]>1){
                        Color foodColor = new Color(Color.yellow.getRGB()+food[i][j]*10);
                        g.setColor(foodColor);
                        g.fillOval(i*UNIT_SIZE,j*UNIT_SIZE,UNIT_SIZE,UNIT_SIZE);
                    }
                }
            }
            //drawing bugs
            g.setColor(Color.white);
            for(int i=0;i<recvBugs.length;i++){
                if(recvBugs[i]!=null){
                g.fillRect(recvBugs[i].currentX*UNIT_SIZE, recvBugs[i].currentY*UNIT_SIZE, UNIT_SIZE,UNIT_SIZE);}
            }
            //generation display up top
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Generation: " + generationNumber, 10, 20);
        }
        //algorithm is done notification
        else{
            int batch=Grank0[0]+1;
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 15));
            FontMetrics metrics = getFontMetrics(g.getFont());
            g.drawString("A bug from batch " + batch + ",", (SCREEN_WIDTH-metrics.stringWidth("A bug from batch x,"))/2,SCREEN_HEIGHT/2-20);
            g.drawString("found the proper amount of food to survive", (SCREEN_WIDTH-metrics.stringWidth("found the proper amount of food to survive"))/2,SCREEN_HEIGHT/2);
            g.drawString("and teach it's youngins in " + generationNumber + " generations", (SCREEN_WIDTH-metrics.stringWidth("and teach it's youngins in x generations"))/2,(SCREEN_HEIGHT/2)+20);
        }
    }

    public void makeFood(){
            for (int i=0; i<amount_of_food; i++){
                int foodX=random.nextInt(SCREEN_WIDTH/UNIT_SIZE);
                int foodY=random.nextInt(SCREEN_HEIGHT/UNIT_SIZE);
                if (food[foodX][foodY]<=0) {
                    food[foodX][foodY]=1;
                }
                else i--;
            }
    }
    public void foodIntoMatrix(int[] foodArr, int[][] foodMat){
        for(int i=0;i<SCREEN_WIDTH / UNIT_SIZE;i++){
            for (int j=0;j<SCREEN_HEIGHT / UNIT_SIZE;j++){
                foodMat[i][j]=foodArr[i*SCREEN_HEIGHT / UNIT_SIZE+j];
            }
        }
    }
    public void replenishFood(){
        for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++){
            for(int j=0;j<SCREEN_WIDTH/UNIT_SIZE;j++){
                if(food[i][j]!=0) food[i][j]=1;
            }
        }
    }

    public void populate(){
        if(initialPopulation){
            initialPopulation = false;
            for (int i = 0; i < populationSize; i++) buggy[i] = new GA_dist_bug();
        }
        else crossBreed();
    }

    public void crossBreed(){
        //the following is so our bugs don't get stuck repeating "bad moves"
        int min = findBest(parents);
        if(lastGenBest > min){
            lastGenBest = min;
        }
        else generationsWithoutChange++;
        if(generationsWithoutChange>=8){
            mutationRate/=2;
            generationsWithoutChange=0;
            mutationUpCounter=1;
        }
        if(mutationUpCounter==0){
            mutationUpCounter=999;
            mutationRate*=2;
        }
        mutationUpCounter--;
        //now my children shall be born
        int parent1=0;
        int parent2=0;
        for(int i=0;i<numberOfParents;i++){
            buggy[i*6].movements = parents[i].movements;
            //elitism
        }
        for(int i=1;i<populationSize;i++){
            boolean helper = true;
            while(helper){
                parent1 = random.nextInt(4);
                parent2 = random.nextInt(4);
                if(parent1!=parent2) helper = false;
            }
            int geneSplit = random.nextInt(GA_dist_bug.genes);
            for(int j=0;j<geneSplit;j++){
                if(i!=batchSize && i!=batchSize*2 && i!= batchSize*3){
                    buggy[i].movements[j]=parents[parent1].movements[j];
                    mutate(buggy[i], j);
                }
            }
            for(int j = geneSplit;j< GA_dist_bug.genes;j++){
                if(i!=batchSize && i!=batchSize*2 && i!= batchSize*3) {
                    buggy[i].movements[j] = parents[parent2].movements[j];
                    mutate(buggy[i], j);
                }
            }
        }
        for(GA_dist_bug bug : buggy){
            bug.hunger = GA_dist_bug.originalHunger;
            for(int i=0;i<SCREEN_WIDTH/UNIT_SIZE;i++){
                for(int j=0;j<SCREEN_HEIGHT/UNIT_SIZE;j++){
                    bug.pickedFood[i][j]=0;
                }
            }
            bug.currentX = SCREEN_WIDTH/UNIT_SIZE/2;
            bug.currentY = SCREEN_WIDTH/UNIT_SIZE/2;
            bug.mover=0;
        }
    }
    public int findBest(GA_dist_bug[] bug){
        int min = bug[0].hunger;
        for (int i = 1; i < bug.length; i++) {
            if (bug[i].hunger < min) {
                min = bug[i].hunger;
            }
        }
        return min;
    }
    public void mutate(GA_dist_bug buug, int i) {
        if (random.nextInt(mutationRate) == 1) {
            int newMove = random.nextInt(4);
            switch (newMove) {
                case 0:
                    buug.movements[i] = 'L';
                    break;
                case 1:
                    buug.movements[i] = 'R';
                    break;
                case 2:
                    buug.movements[i] = 'D';
                    break;
                case 3:
                    buug.movements[i] = 'U';
                    break;
            }
        }
    }
    public GA_dist_bug selection(GA_dist_bug[] buug) {
        int min = 999;
        GA_dist_bug parentBugger = null;
        for(GA_dist_bug bug : buug){
            if(bug.hunger<min){
                min = bug.hunger;
                parentBugger = bug;
            }
        }
        return parentBugger;
    }
    public void makeMPIcall(){
        MPI.COMM_WORLD.Allreduce(GA_dist_bug.localDone,0, GA_dist_bug.globalDone,0, 1, MPI.INT, MPI.MAX);
        if(GA_dist_bug.globalDone[0]==1){
            MPI.COMM_WORLD.Allreduce(Lrank0,0, Grank0,0, 1, MPI.INT, MPI.MIN);
            done=true;
            return;
        }
        generationNumber++;
        parentBug[0]=selection(recvBugs);
        replenishFood();
        MPI.COMM_WORLD.Gather(parentBug,0,parentBug.length,MPI.OBJECT,parents,0,parentBug.length,MPI.OBJECT,0);

        if(rank == 0){
            populate();
        }
        MPI.COMM_WORLD.Scatter(buggy,0,batchSize,MPI.OBJECT,recvBugs,0,recvBugs.length,MPI.OBJECT,0);

    }
}